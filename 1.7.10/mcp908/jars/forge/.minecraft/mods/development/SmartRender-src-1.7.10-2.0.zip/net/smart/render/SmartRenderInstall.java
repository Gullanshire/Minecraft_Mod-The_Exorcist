package net.smart.render;

import net.smart.utilities.*;

public class SmartRenderInstall
{
	public final static Name ModelRenderer_compiled = new Name("compiled", "field_78812_q", "t");
	public final static Name ModelRenderer_compileDisplayList = new Name("compileDisplayList", "func_78788_d", "d");
	public final static Name ModelRenderer_displayList = new Name("displayList", "field_78811_r", "u");
	public final static Name RenderPlayer_modelBipedMain = new Name("modelBipedMain", "field_77109_a", "f");
	public final static Name RenderPlayer_modelArmorChestplate = new Name("modelArmorChestplate", "field_77108_b", "g");
	public final static Name RenderPlayer_modelArmor = new Name("modelArmor", "field_77111_i", "h");
}