package net.smart.render;

public class SmartRenderInfo
{
	public static final String ModId = "SmartRender";
	public static final String ModName = "Smart Render";
	public static final String ModVersion = "2.0";
}
