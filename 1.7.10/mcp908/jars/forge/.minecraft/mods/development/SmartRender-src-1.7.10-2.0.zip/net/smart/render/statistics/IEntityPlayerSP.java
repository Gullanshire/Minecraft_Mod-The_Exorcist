package net.smart.render.statistics;

public interface IEntityPlayerSP
{
	SmartStatistics getStatistics();
}