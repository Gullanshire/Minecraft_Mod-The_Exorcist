package net.smart.moving.render;

import net.smart.moving.*;

public abstract class SmartRenderContext extends SmartMovingContext
{
	public static final int Scale = 0;
	public static final int NoScaleStart = 1;
	public static final int NoScaleEnd = 2;
}
