package net.smart.moving;

import net.minecraft.block.material.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.EntityPlayer.*;
import net.minecraft.nbt.*;

public interface IEntityPlayerSP
{
	SmartMoving getMoving();

	boolean getSleepingField();

	boolean getIsJumpingField();

	boolean getIsInWebField();

	void setIsInWebField(boolean b);

	Minecraft getMcField();

	void setMoveForwardField(float f);

	void setMoveStrafingField(float f);

	void setIsJumpingField(boolean flag);

	void localMoveEntity(double d, double d1, double d2);

	EnumStatus localSleepInBedAt(int i, int j, int k);

	float localGetBrightness(float f);

	int localGetBrightnessForRender(float f);

	void localUpdateEntityActionState();

	boolean localIsInsideOfMaterial(Material material);

	void localWriteEntityToNBT(NBTTagCompound nBTTagCompound);

	boolean localIsSneaking();

	float localGetFOVMultiplier();
}