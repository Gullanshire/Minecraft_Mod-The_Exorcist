package net.smart.moving;

public interface ISmartMovingClient
{
	float getMaximumExhaustion();

	float getMaximumUpJumpCharge();

	float getMaximumHeadJumpCharge();

	void setMaximumExhaustionValue(String key, float value);

	float getMaximumExhaustionValue(String key);

	boolean removeMaximumExhaustionValue(String key);

	void setNativeUserInterfaceDrawing(boolean value);

	boolean getNativeUserInterfaceDrawing();
}