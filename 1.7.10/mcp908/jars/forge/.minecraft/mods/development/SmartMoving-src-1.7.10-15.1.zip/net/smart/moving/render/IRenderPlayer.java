package net.smart.moving.render;

import net.minecraft.client.entity.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;

public interface IRenderPlayer
{
	void superRenderRenderPlayer(AbstractClientPlayer entityplayer, double d, double d1, double d2, float f, float renderPartialTicks);

	void superRenderRotatePlayer(AbstractClientPlayer entityplayer, float totalTime, float actualRotation, float f2);

	void superRenderRenderPlayerAt(AbstractClientPlayer entityplayer, double d, double d1, double d2);

	void superRenderRenderName(EntityLivingBase par1EntityPlayer, double par2, double par4, double par6);

	RenderManager getRenderManager();

	IModelPlayer getPlayerModelBipedMain();

	IModelPlayer getPlayerModelArmorChestplate();

	IModelPlayer getPlayerModelArmor();

	IModelPlayer[] getPlayerModels();
}
