package net.smart.moving;

public interface ILocalUserNameProvider
{
	String getLocalConfigUserName();

	String getLocalSpeedUserName();
}
