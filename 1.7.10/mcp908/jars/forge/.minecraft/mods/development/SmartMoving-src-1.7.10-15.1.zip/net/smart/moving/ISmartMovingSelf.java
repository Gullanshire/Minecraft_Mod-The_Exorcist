package net.smart.moving;

public interface ISmartMovingSelf
{
	float getExhaustion();

	float getUpJumpCharge();
	
	float getHeadJumpCharge();

	void addExhaustion(float factor);

	void setMaxExhaustionForAction(float maxExhaustionForAction);

	void setMaxExhaustionToStartAction(float maxExhaustionToStartAction);
}