package net.smart.moving.playerapi;

import net.minecraft.client.entity.*;
import net.minecraft.entity.player.*;
import net.smart.moving.*;

public abstract class SmartMoving
{
	public static final String SPC_ID = "Single Player Commands";

	public static void register()
	{
		SmartMovingPlayerBase.registerPlayerBase();
		SmartMovingServerPlayerBase.registerPlayerBase();
	}

	public static IEntityPlayerSP getPlayerBase(EntityPlayer entityPlayer)
	{
		if(entityPlayer instanceof EntityPlayerSP)
			return SmartMovingPlayerBase.getPlayerBase((EntityPlayerSP)entityPlayer);
		return null;
	}

	public static IEntityPlayerMP getServerPlayerBase(EntityPlayer entityPlayer)
	{
		if(entityPlayer instanceof EntityPlayerMP)
			return SmartMovingServerPlayerBase.getPlayerBase(entityPlayer);
		return null;
	}
}
