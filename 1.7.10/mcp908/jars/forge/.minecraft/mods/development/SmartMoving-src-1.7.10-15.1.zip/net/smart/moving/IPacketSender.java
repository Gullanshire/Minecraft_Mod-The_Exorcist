package net.smart.moving;

public interface IPacketSender
{
	void sendPacket(byte[] byteArray);
}
