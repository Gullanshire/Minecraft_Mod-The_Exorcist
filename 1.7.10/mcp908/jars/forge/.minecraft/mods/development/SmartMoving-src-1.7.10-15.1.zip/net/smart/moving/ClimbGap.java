package net.smart.moving;

import net.minecraft.block.*;

public class ClimbGap
{
	public Block Block;
	public int Meta;
	public boolean CanStand;
	public boolean MustCrawl;
	public Orientation Direction;
	public boolean SkipGaps;

	public ClimbGap()
	{
		reset();
	}

	public void reset()
	{
		Block = null;
		Meta = -1;
		CanStand = false;
		MustCrawl = false;
		Direction = null;
		SkipGaps = false;
	}
}