package net.smart.moving;

import net.minecraft.client.*;

public class LocalUserNameProvider extends SmartMovingContext implements ILocalUserNameProvider
{
	public String getLocalConfigUserName()
	{
		return Options._localUserHasChangeConfigRight.value ? Minecraft.getMinecraft().thePlayer.getGameProfile().getName() : null;
	}

	public String getLocalSpeedUserName()
	{
		return Options._localUserHasChangeSpeedRight.value ? Minecraft.getMinecraft().thePlayer.getGameProfile().getName() : null;
	}
}