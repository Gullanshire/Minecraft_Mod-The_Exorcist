package net.smart.moving.playerapi;

import net.minecraft.entity.player.*;

import net.smart.moving.*;

public class SmartMovingFactory extends net.smart.moving.SmartMovingFactory
{
	public static void initialize()
	{
		if(!isInitialized())
			new SmartMovingFactory();
	}

	protected net.smart.moving.SmartMoving doGetInstance(EntityPlayer entityPlayer)
	{
		net.smart.moving.SmartMoving moving = super.doGetInstance(entityPlayer);
		if(moving != null)
			return moving;

   		IEntityPlayerSP playerBase = SmartMoving.getPlayerBase(entityPlayer);
   		if(playerBase != null)
   			return playerBase.getMoving();

   		return null;
	}
}
