package net.smart.core;

import java.util.*;
import com.google.common.eventbus.*;
import cpw.mods.fml.common.*;

public class SmartCoreContainer extends DummyModContainer
{
	public SmartCoreContainer()
	{
		super(createMetadata());
	}

	public boolean registerBus(EventBus bus, LoadController controller)
	{
		return true;
	}

	private static ModMetadata createMetadata()
	{
		ModMetadata meta = new ModMetadata();

		meta.modId = "SmartCore";
		meta.name = SmartCoreInfo.ModName;
		meta.version = SmartCoreInfo.ModVersion;
		meta.description = "Adds some core hooks required by Smart Moving";
		meta.url = "http://www.minecraftforum.net/topic/738498-";
		meta.authorList = Arrays.asList(new String[] { "Divisor" });

		return meta;
	}
}
