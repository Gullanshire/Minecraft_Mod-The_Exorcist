package net.smart.core;

public class SmartCoreInfo
{
	public static final String ModName = "Smart Core";
	public static final String ModVersion = "1.0";
}
