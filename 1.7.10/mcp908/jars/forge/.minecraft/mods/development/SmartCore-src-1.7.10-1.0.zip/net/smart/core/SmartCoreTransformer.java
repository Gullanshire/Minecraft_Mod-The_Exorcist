package net.smart.core;

import net.minecraft.launchwrapper.*;

public class SmartCoreTransformer implements IClassTransformer
{
	public byte[] transform(String name, String transformedName, byte[] bytes)
	{
		if(transformedName.equals(NetServerHandlerClassVisitor.targetClassName))
			return NetServerHandlerClassVisitor.transform(bytes, SmartCorePlugin.isObfuscated);
		return bytes;
	}
}