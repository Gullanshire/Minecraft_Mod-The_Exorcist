package net.smart.core;

import java.util.*;

import cpw.mods.fml.relauncher.*;

@IFMLLoadingPlugin.MCVersion("1.7.10")
public class SmartCorePlugin implements IFMLLoadingPlugin
{
	public static boolean isObfuscated;

	@Override
	public String[] getASMTransformerClass()
	{
		return new String[] { "net.smart.core.SmartCoreTransformer" };
	}

	@Override
	public String getAccessTransformerClass()
	{
		return null;
	}

	@Override
	public String getModContainerClass()
	{
		return "net.smart.core.SmartCoreContainer";
	}

	@Override
	public String getSetupClass()
	{
		return null;
	}

	@Override
	public void injectData(Map<String, Object> data)
	{
		isObfuscated = (Boolean)data.get("runtimeDeobfuscationEnabled");
	}
}